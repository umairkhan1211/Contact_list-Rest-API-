import React, { Component } from "react";
import "./Mycomponent/contacts.css";
import Contactitems from "./Contactitems";
import Contactinfo from "./Contactinfo";

class Contacts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedContact: null, // To store the selected contact
    };
  }

  // Handler function to update selected contact
  handleContactClick = (id) => {
    let selectedContact = this.props.data.find((contact) => contact.id === id);
    console.log("Selected Contact:", selectedContact); // Check if correct contact is selected
    this.setState({ selectedContact });
  };
  

  render() {
    return (
      <>
        <div className="left-container">
          <div className="head">
            <p className="h4">Search for a contact</p>
            <div className="h1">
              <h4>Name, email, or phone number</h4>
              <i className="fa-solid fa-magnifying-glass"></i>
            </div>
          </div>
          {this.props.data.map((element) => (
            <div className="list" key={element.id}>
              <Contactitems
                Name={element.first_name}
                designation="Developer"
                imgUrl={element.avatar}
                onClick={() => this.handleContactClick(element.id)} // Pass click handler
             
                
                
              />
              <Contactinfo contact={this.state.selectedContact} />
            </div>
          ))}
        </div>
      </>
    );
  }
}

export default Contacts;
