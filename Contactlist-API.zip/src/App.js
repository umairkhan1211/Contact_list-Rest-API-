import "./App.css";
import React, { Component } from "react";
import Navbar from "./components/Navbar";
import Contacts from "./components/Contacts";
import Contactinfo from "./components/Contactinfo";

export default class App extends Component {
  constructor() {
    super();
    this.state = {
      data: [],
      page: 1,
      totalPages: 2,
    };
  }

  async fetchContacts(page) {
    let url = `https://reqres.in/api/users?page=${page}`;
    try {
      let response = await fetch(url);
      if (!response.ok) {
        throw new Error('Failed to fetch contacts');
      }
      let parsedData = await response.json();
      console.log("Fetched Data:", parsedData); // Check fetched data structure
      this.setState({ data: parsedData.data, totalPages: parsedData.total_pages, page });
    } catch (error) {
      console.error('Error fetching contacts:', error);
    }
  }
  

  componentDidMount() {
    this.fetchContacts(this.state.page);
  }

  handleLeft = () => {
    if (this.state.page > 1) {
      this.fetchContacts(this.state.page - 1);
    }
  };

  handleRight = () => {
    if (this.state.page < this.state.totalPages) {
      this.fetchContacts(this.state.page + 1);
    }
  };

  render() {
    return (
      <>
        <Navbar handleLeft={this.handleLeft} handleRight={this.handleRight} />
        <Contacts data={this.state.data} />
        <Contactinfo contact={this.state.selectedContact} />
      </>
    );
  }
}
